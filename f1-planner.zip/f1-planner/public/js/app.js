// F1 Planner — Frontend JavaScript

// Toggle favorite via AJAX
async function toggleFavorite(btn, raceId) {
    btn.disabled = true;

    try {
        const res = await fetch('/api/toggle_favorite.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ race_id: raceId })
        });

        if (res.status === 401) {
            window.location.href = '/login.php';
            return;
        }

        const data = await res.json();

        if (data.status === 'added') {
            btn.classList.add('active');
            btn.title = 'Remove from favorites';
            showToast('⭐ Added to your planner!');
        } else if (data.status === 'removed') {
            btn.classList.remove('active');
            btn.title = 'Add to favorites';
            showToast('Removed from planner');

            // If we're on the planner page, remove the card
            const card = btn.closest('.race-card');
            if (card && window.location.pathname.includes('planner')) {
                card.style.transition = 'opacity 0.3s, transform 0.3s';
                card.style.opacity = '0';
                card.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    card.remove();
                    // Reload to update stats
                    setTimeout(() => location.reload(), 100);
                }, 300);
            }
        }
    } catch (err) {
        showToast('Something went wrong. Try again.', 'error');
    } finally {
        btn.disabled = false;
    }
}

// Live search filter on home page
const searchInput = document.querySelector('.filter-input');
if (searchInput && !searchInput.form) {
    searchInput.addEventListener('input', debounce(() => {
        searchInput.form && searchInput.form.submit();
    }, 500));
}

// Toast notification
function showToast(message, type = 'success') {
    const existing = document.querySelector('.f1-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'f1-toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 2rem;
        right: 2rem;
        background: ${type === 'error' ? '#7a0000' : '#1a1a1a'};
        color: #f0f0f0;
        border: 1px solid ${type === 'error' ? '#E10600' : '#39FF14'};
        border-radius: 8px;
        padding: 0.85rem 1.4rem;
        font-family: 'Titillium Web', sans-serif;
        font-size: 0.9rem;
        font-weight: 600;
        z-index: 9999;
        transform: translateY(20px);
        opacity: 0;
        transition: all 0.3s ease;
        box-shadow: 0 4px 20px rgba(0,0,0,0.5);
    `;
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
        toast.style.transform = 'translateY(0)';
        toast.style.opacity   = '1';
    });

    setTimeout(() => {
        toast.style.transform = 'translateY(20px)';
        toast.style.opacity   = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Debounce helper
function debounce(fn, delay) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}
