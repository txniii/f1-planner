<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

startSession();
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$input   = json_decode(file_get_contents('php://input'), true);
$raceId  = (int)($input['race_id'] ?? 0);
$uid     = $_SESSION['user_id'];

if (!$raceId) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid race_id']);
    exit;
}

$db = getDB();

// Check if already favorited
$check = $db->prepare('SELECT id FROM favorites WHERE user_id = ? AND race_id = ?');
$check->execute([$uid, $raceId]);
$existing = $check->fetch();

if ($existing) {
    // Remove favorite
    $del = $db->prepare('DELETE FROM favorites WHERE user_id = ? AND race_id = ?');
    $del->execute([$uid, $raceId]);
    echo json_encode(['status' => 'removed']);
} else {
    // Add favorite
    $ins = $db->prepare('INSERT INTO favorites (user_id, race_id) VALUES (?, ?)');
    $ins->execute([$uid, $raceId]);
    echo json_encode(['status' => 'added']);
}
