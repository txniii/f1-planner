
</main>

<footer class="footer">
    <div class="footer-inner">
        <span class="logo-f1 footer-logo">F1</span>
        <span class="footer-text">Race Weekend Planner &mdash; <?= date('Y') ?> Season</span>
        <span class="footer-note">Data via Formula-1 RapidAPI</span>
    </div>
</footer>

<script src="/public/js/app.js"></script>
</body>
</html>
