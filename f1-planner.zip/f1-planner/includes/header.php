<?php
require_once __DIR__ . '/auth.php';
startSession();
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'F1 Race Weekend Planner') ?></title>
    <link rel="stylesheet" href="/public/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700;900&family=Orbitron:wght@700;900&display=swap" rel="stylesheet">
</head>
<body>

<nav class="navbar">
    <a href="/index.php" class="nav-logo">
        <span class="logo-f1">F1</span><span class="logo-text">Planner</span>
    </a>

    <div class="nav-links">
        <a href="/index.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">Calendar</a>

        <?php if ($user): ?>
            <a href="/pages/planner.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'planner.php' ? 'active' : '' ?>">My Planner</a>
            <?php if ($user['role'] === 'admin'): ?>
                <a href="/admin/index.php" class="nav-link admin-link">Admin</a>
            <?php endif; ?>
            <div class="nav-user">
                <span class="nav-username">👤 <?= htmlspecialchars($user['username']) ?></span>
                <a href="/logout.php" class="btn btn-outline btn-sm">Logout</a>
            </div>
        <?php else: ?>
            <a href="/login.php" class="btn btn-outline btn-sm">Login</a>
            <a href="/register.php" class="btn btn-primary btn-sm">Register</a>
        <?php endif; ?>
    </div>
</nav>

<main class="main-content">
