<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

$db    = getDB();
$id    = (int)($_GET['id'] ?? 0);
$race  = null;
$error = '';
$isEdit = false;

if ($id) {
    $stmt = $db->prepare('SELECT * FROM races WHERE id = ?');
    $stmt->execute([$id]);
    $race = $stmt->fetch();
    $isEdit = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'grand_prix_name' => trim($_POST['grand_prix_name'] ?? ''),
        'country'         => trim($_POST['country'] ?? ''),
        'circuit_name'    => trim($_POST['circuit_name'] ?? ''),
        'race_date'       => $_POST['race_date'] ?? '',
        'description'     => trim($_POST['description'] ?? ''),
        'flag_emoji'      => trim($_POST['flag_emoji'] ?? ''),
        'circuit_length'  => trim($_POST['circuit_length'] ?? ''),
        'lap_count'       => (int)($_POST['lap_count'] ?? 0),
        'status'          => $_POST['status'] ?? 'upcoming',
    ];

    if (!$fields['grand_prix_name'] || !$fields['country'] || !$fields['circuit_name'] || !$fields['race_date']) {
        $error = 'Grand Prix name, country, circuit and date are required.';
    } else {
        if ($isEdit) {
            $sql = 'UPDATE races SET grand_prix_name=?, country=?, circuit_name=?, race_date=?,
                    description=?, flag_emoji=?, circuit_length=?, lap_count=?, status=? WHERE id=?';
            $params = array_values($fields);
            $params[] = $id;
        } else {
            $sql = 'INSERT INTO races (grand_prix_name, country, circuit_name, race_date,
                    description, flag_emoji, circuit_length, lap_count, status) VALUES (?,?,?,?,?,?,?,?,?)';
            $params = array_values($fields);
        }
        $db->prepare($sql)->execute($params);

        // If adding, also insert 5 default sessions
        if (!$isEdit) {
            $newId = $db->lastInsertId();
            $raceDate = new DateTime($fields['race_date']);
            $sessions = [
                ['Practice 1',  '-2 days', '10:30'],
                ['Practice 2',  '-2 days', '14:00'],
                ['Practice 3',  '-1 days', '10:30'],
                ['Qualifying',  '-1 days', '14:00'],
                ['Race',         '+0 days', '13:00'],
            ];
            foreach ($sessions as [$name, $offset, $time]) {
                $d = clone $raceDate;
                $d->modify($offset);
                $dt = $d->format('Y-m-d') . ' ' . $time . ':00';
                $db->prepare('INSERT INTO sessions (race_id, session_name, session_datetime) VALUES (?,?,?)')
                   ->execute([$newId, $name, $dt]);
            }
        }

        header('Location: /admin/index.php');
        exit;
    }
}

$pageTitle = ($isEdit ? 'Edit' : 'Add') . ' Race — Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<a href="/admin/index.php" class="back-link">← Back to Admin</a>

<div class="page-hero">
    <h1><?= $isEdit ? 'Edit' : 'Add New' ?> <span class="red-accent">Race</span></h1>
</div>

<?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" class="admin-form">
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Grand Prix Name *</label>
            <input class="form-input" type="text" name="grand_prix_name" required
                value="<?= htmlspecialchars($race['grand_prix_name'] ?? '') ?>"
                placeholder="Monaco Grand Prix">
        </div>
        <div class="form-group">
            <label class="form-label">Country *</label>
            <input class="form-input" type="text" name="country" required
                value="<?= htmlspecialchars($race['country'] ?? '') ?>"
                placeholder="Monaco">
        </div>
    </div>

    <div class="form-group">
        <label class="form-label">Circuit Name *</label>
        <input class="form-input" type="text" name="circuit_name" required
            value="<?= htmlspecialchars($race['circuit_name'] ?? '') ?>"
            placeholder="Circuit de Monaco">
    </div>

    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Race Date *</label>
            <input class="form-input" type="date" name="race_date" required
                value="<?= htmlspecialchars($race['race_date'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-input" name="status">
                <option value="upcoming" <?= ($race['status'] ?? 'upcoming') === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
                <option value="completed" <?= ($race['status'] ?? '') === 'completed' ? 'selected' : '' ?>>Completed</option>
            </select>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Flag Emoji</label>
            <input class="form-input" type="text" name="flag_emoji"
                value="<?= htmlspecialchars($race['flag_emoji'] ?? '') ?>"
                placeholder="🇲🇨">
        </div>
        <div class="form-group">
            <label class="form-label">Circuit Length</label>
            <input class="form-input" type="text" name="circuit_length"
                value="<?= htmlspecialchars($race['circuit_length'] ?? '') ?>"
                placeholder="3.337 km">
        </div>
    </div>

    <div class="form-group">
        <label class="form-label">Lap Count</label>
        <input class="form-input" type="number" name="lap_count" min="1"
            value="<?= htmlspecialchars($race['lap_count'] ?? '') ?>"
            placeholder="78">
    </div>

    <div class="form-group">
        <label class="form-label">Description</label>
        <textarea class="notes-textarea" name="description" style="min-height:80px;"
            placeholder="Describe the circuit and race..."><?= htmlspecialchars($race['description'] ?? '') ?></textarea>
    </div>

    <?php if (!$isEdit): ?>
    <div class="alert alert-info" style="margin-bottom:1rem;">
        Practice, Qualifying and Race sessions will be automatically created based on the race date.
    </div>
    <?php endif; ?>

    <div class="d-flex gap-1">
        <button type="submit" class="btn btn-primary btn-lg">
            <?= $isEdit ? 'Update Race' : 'Add Race' ?>
        </button>
        <a href="/admin/index.php" class="btn btn-outline btn-lg">Cancel</a>
    </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
