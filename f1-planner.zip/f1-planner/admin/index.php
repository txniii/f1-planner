<?php
$pageTitle = 'Admin Panel — F1 Planner';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

requireAdmin();

$db = getDB();
$msg = '';

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delId = (int)$_POST['delete_id'];
    $db->prepare('DELETE FROM races WHERE id = ?')->execute([$delId]);
    $msg = 'Race deleted successfully.';
}

$races = $db->query('SELECT * FROM races ORDER BY race_date ASC')->fetchAll();
$totalUsers = $db->query('SELECT COUNT(*) FROM users')->fetchColumn();
$totalFavs  = $db->query('SELECT COUNT(*) FROM favorites')->fetchColumn();
$totalNotes = $db->query('SELECT COUNT(*) FROM notes')->fetchColumn();
?>

<div class="page-hero">
    <h1>Admin <span class="red-accent">Panel</span></h1>
    <p class="subtitle">Manage races, users and data</p>
</div>

<!-- Stats -->
<div class="stats-row">
    <div class="stat-card">
        <div class="stat-value"><?= count($races) ?></div>
        <div class="stat-label">Total Races</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $totalUsers ?></div>
        <div class="stat-label">Registered Users</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $totalFavs ?></div>
        <div class="stat-label">Total Favorites</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= $totalNotes ?></div>
        <div class="stat-label">Notes Written</div>
    </div>
</div>

<?php if ($msg): ?>
    <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.2rem;">
    <div class="section-title" style="margin-bottom:0;">Race Management</div>
    <a href="/admin/race_form.php" class="btn btn-primary">+ Add New Race</a>
</div>

<div style="overflow-x:auto;">
<table class="admin-table">
    <thead>
        <tr>
            <th>Flag</th>
            <th>Grand Prix</th>
            <th>Country</th>
            <th>Circuit</th>
            <th>Race Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($races as $race): ?>
        <tr>
            <td><?= $race['flag_emoji'] ?></td>
            <td><strong><?= htmlspecialchars($race['grand_prix_name']) ?></strong></td>
            <td><?= htmlspecialchars($race['country']) ?></td>
            <td style="color:var(--text-muted);font-size:0.85rem;"><?= htmlspecialchars($race['circuit_name']) ?></td>
            <td><?= date('M j, Y', strtotime($race['race_date'])) ?></td>
            <td><span class="badge badge-<?= $race['status'] ?>"><?= ucfirst($race['status']) ?></span></td>
            <td>
                <div class="d-flex gap-1">
                    <a href="/admin/race_form.php?id=<?= $race['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                    <form method="POST" onsubmit="return confirm('Delete this race?');" style="display:inline;">
                        <input type="hidden" name="delete_id" value="<?= $race['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
