<?php
$pageTitle = 'My Planner — F1 Planner';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

requireLogin();

$db  = getDB();
$uid = $_SESSION['user_id'];

// Get favorites with race info
$stmt = $db->prepare('
    SELECT r.*, f.created_at as fav_date
    FROM favorites f
    JOIN races r ON r.id = f.race_id
    WHERE f.user_id = ?
    ORDER BY r.race_date ASC
');
$stmt->execute([$uid]);
$favRaces = $stmt->fetchAll();

// Get notes with race info
$nstmt = $db->prepare('
    SELECT n.*, r.grand_prix_name, r.flag_emoji, r.race_date
    FROM notes n
    JOIN races r ON r.id = n.race_id
    WHERE n.user_id = ?
    ORDER BY n.updated_at DESC
');
$nstmt->execute([$uid]);
$notes = $nstmt->fetchAll();
?>

<div class="page-hero">
    <h1>My <span class="red-accent">Planner</span></h1>
    <p class="subtitle">Your saved races and personal notes</p>
</div>

<!-- Stats -->
<div class="stats-row">
    <div class="stat-card">
        <div class="stat-value"><?= count($favRaces) ?></div>
        <div class="stat-label">Saved Races</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><?= count($notes) ?></div>
        <div class="stat-label">Notes Written</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">
            <?= count(array_filter($favRaces, fn($r) => $r['status'] === 'upcoming')) ?>
        </div>
        <div class="stat-label">Upcoming</div>
    </div>
</div>

<!-- Favorites -->
<div class="section-title">Saved Race Weekends</div>

<?php if (empty($favRaces)): ?>
<div class="planner-empty">
    <div class="empty-icon">⭐</div>
    <h2>No Favorites Yet</h2>
    <p>Browse the race calendar and click ☆ Fav to save a race here.</p>
    <a href="/index.php" class="btn btn-primary" style="margin-top:1.2rem;">Browse Calendar</a>
</div>
<?php else: ?>
<div class="races-grid" style="margin-bottom:2.5rem;">
    <?php foreach ($favRaces as $race): ?>
    <div class="race-card">
        <div class="race-card-header">
            <div>
                <div class="race-round">Saved <?= date('M j', strtotime($race['fav_date'])) ?></div>
                <div style="color:var(--text-muted);font-size:0.8rem;margin-top:2px;">
                    <?= date('M d, Y', strtotime($race['race_date'])) ?>
                </div>
            </div>
            <div class="race-flag"><?= $race['flag_emoji'] ?></div>
        </div>
        <div class="race-card-body">
            <div class="race-gp-name"><?= htmlspecialchars($race['grand_prix_name']) ?></div>
            <div class="race-circuit">📍 <?= htmlspecialchars($race['circuit_name']) ?></div>
        </div>
        <div class="race-card-footer">
            <span class="badge badge-<?= $race['status'] ?>"><?= ucfirst($race['status']) ?></span>
            <div class="d-flex gap-1 align-center">
                <button
                    class="fav-btn active"
                    onclick="toggleFavorite(this, <?= $race['id'] ?>)"
                >Fav</button>
                <a href="/pages/race.php?id=<?= $race['id'] ?>" class="btn btn-primary btn-sm">View →</a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Notes -->
<?php if (!empty($notes)): ?>
<div class="section-title">My Notes</div>
<div style="display:flex;flex-direction:column;gap:1rem;margin-bottom:2rem;">
    <?php foreach ($notes as $n): ?>
    <div style="background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius-lg);padding:1.2rem 1.4rem;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.6rem;">
            <span style="font-weight:700;"><?= $n['flag_emoji'] ?> <?= htmlspecialchars($n['grand_prix_name']) ?></span>
            <span style="color:var(--text-muted);font-size:0.8rem;">Updated <?= date('M j, Y', strtotime($n['updated_at'])) ?></span>
        </div>
        <p style="color:var(--text-muted);font-size:0.92rem;line-height:1.6;"><?= nl2br(htmlspecialchars($n['note_text'])) ?></p>
        <div style="margin-top:0.8rem;">
            <a href="/pages/race.php?id=<?= $n['race_id'] ?>" class="btn btn-outline btn-sm">Edit Note →</a>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
