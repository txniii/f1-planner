<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: /index.php'); exit; }

// Fetch race
$stmt = $db->prepare('SELECT * FROM races WHERE id = ?');
$stmt->execute([$id]);
$race = $stmt->fetch();
if (!$race) { header('Location: /index.php'); exit; }

// Fetch sessions
$sstmt = $db->prepare('SELECT * FROM sessions WHERE race_id = ? ORDER BY session_datetime');
$sstmt->execute([$id]);
$sessions = $sstmt->fetchAll();

// Favorite state
$isFavorite = false;
$note       = '';
if (isLoggedIn()) {
    $uid    = $_SESSION['user_id'];
    $fstmt  = $db->prepare('SELECT id FROM favorites WHERE user_id = ? AND race_id = ?');
    $fstmt->execute([$uid, $id]);
    $isFavorite = (bool)$fstmt->fetch();

    $nstmt = $db->prepare('SELECT note_text FROM notes WHERE user_id = ? AND race_id = ?');
    $nstmt->execute([$uid, $id]);
    $noteRow = $nstmt->fetch();
    $note = $noteRow ? $noteRow['note_text'] : '';
}

// Handle note save
$noteMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_text']) && isLoggedIn()) {
    $uid      = $_SESSION['user_id'];
    $noteText = trim($_POST['note_text']);
    // Upsert note
    $check = $db->prepare('SELECT id FROM notes WHERE user_id = ? AND race_id = ?');
    $check->execute([$uid, $id]);
    if ($check->fetch()) {
        $upd = $db->prepare('UPDATE notes SET note_text = ? WHERE user_id = ? AND race_id = ?');
        $upd->execute([$noteText, $uid, $id]);
    } else {
        $ins = $db->prepare('INSERT INTO notes (user_id, race_id, note_text) VALUES (?, ?, ?)');
        $ins->execute([$uid, $id, $noteText]);
    }
    $note    = $noteText;
    $noteMsg = 'Note saved!';
}

$pageTitle = $race['grand_prix_name'] . ' — F1 Planner';
require_once __DIR__ . '/../includes/header.php';
?>

<a href="/index.php" class="back-link">← Back to Calendar</a>

<!-- Race Hero -->
<div class="race-detail-hero">
    <div>
        <div style="margin-bottom:0.5rem;">
            <span class="badge badge-<?= $race['status'] ?>"><?= ucfirst($race['status']) ?></span>
        </div>
        <div class="detail-gp-name"><?= htmlspecialchars($race['grand_prix_name']) ?></div>
        <div style="color:var(--text-muted);margin-bottom:1rem;"><?= htmlspecialchars($race['country']) ?> &bull; <?= htmlspecialchars($race['circuit_name']) ?></div>
        <p style="color:var(--text-muted);font-size:0.95rem;line-height:1.7;"><?= htmlspecialchars($race['description']) ?></p>

        <div class="detail-meta">
            <div class="detail-meta-item">
                <span class="detail-meta-label">Race Date</span>
                <strong><?= date('D, M j, Y', strtotime($race['race_date'])) ?></strong>
            </div>
            <?php if ($race['circuit_length']): ?>
            <div class="detail-meta-item">
                <span class="detail-meta-label">Circuit Length</span>
                <strong><?= htmlspecialchars($race['circuit_length']) ?></strong>
            </div>
            <?php endif; ?>
            <?php if ($race['lap_count']): ?>
            <div class="detail-meta-item">
                <span class="detail-meta-label">Laps</span>
                <strong><?= $race['lap_count'] ?></strong>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div style="text-align:center;">
        <div class="detail-flag"><?= $race['flag_emoji'] ?></div>
        <?php if (isLoggedIn()): ?>
        <button
            class="fav-btn <?= $isFavorite ? 'active' : '' ?> mt-2"
            style="display:block;width:100%;margin-top:1rem;"
            onclick="toggleFavorite(this, <?= $race['id'] ?>)"
        >Favorite</button>
        <?php else: ?>
        <div style="margin-top:1rem;">
            <a href="/login.php" class="btn btn-outline btn-sm">Login to save</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Sessions -->
<div class="section-title">Weekend Schedule</div>
<div class="sessions-list">
<?php if (empty($sessions)): ?>
    <div class="no-results">No sessions listed yet.</div>
<?php else: ?>
    <?php foreach ($sessions as $s):
        $cls = 'session-practice';
        if (stripos($s['session_name'], 'Race') !== false && stripos($s['session_name'], 'Grand') === false) $cls = 'session-race';
        elseif (stripos($s['session_name'], 'Qualifying') !== false) $cls = 'session-qualifying';
    ?>
    <div class="session-row">
        <div class="session-name <?= $cls ?>"><?= htmlspecialchars($s['session_name']) ?></div>
        <div class="session-time"><?= date('D, M j · H:i', strtotime($s['session_datetime'])) ?> UTC</div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>

<!-- Notes (logged in users only) -->
<?php if (isLoggedIn()): ?>
<div class="section-title">My Notes</div>
<div class="notes-area">
    <?php if ($noteMsg): ?>
        <div class="alert alert-success"><?= htmlspecialchars($noteMsg) ?></div>
    <?php endif; ?>
    <form method="POST">
        <textarea
            class="notes-textarea"
            name="note_text"
            placeholder="Add your notes about this race weekend — who to watch, predictions, reminders..."
        ><?= htmlspecialchars($note) ?></textarea>
        <button type="submit" class="btn btn-primary">Save Note</button>
    </form>
</div>
<?php else: ?>
<div class="alert alert-info">
    <a href="/login.php">Login</a> to save favorites and add personal notes.
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
